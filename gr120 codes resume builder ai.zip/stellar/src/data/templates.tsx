
import { ResumeTemplate } from "../types/resume";
import ClassicTemplate from "../components/templates/ClassicTemplate";
import ModernTemplate from "../components/templates/ModernTemplate";
import MinimalistTemplate from "../components/templates/MinimalistTemplate";

export const templates: ResumeTemplate[] = [
  {
    id: "classic",
    name: "Classic",
    thumbnail: "/placeholder.svg",
    component: ClassicTemplate,
  },
  {
    id: "modern",
    name: "Modern",
    thumbnail: "/placeholder.svg",
    component: ModernTemplate,
  },
  {
    id: "minimalist",
    name: "Minimalist",
    thumbnail: "/placeholder.svg",
    component: MinimalistTemplate,
  },
];
