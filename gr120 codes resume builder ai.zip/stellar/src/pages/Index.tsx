
import React from "react";
import { ResumeProvider } from "../contexts/ResumeContext";
import ResumeEditor from "../components/ResumeEditor";
import ResumePreview from "../components/ResumePreview";
import Header from "../components/Header";

const Index: React.FC = () => {
  return (
    <ResumeProvider>
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        
        <main className="flex-grow p-4 lg:p-6">
          <div className="grid gap-6 grid-cols-1 lg:grid-cols-2 max-w-7xl mx-auto">
            <div className="h-[calc(100vh-12rem)]">
              <ResumeEditor />
            </div>
            <div className="h-[calc(100vh-12rem)]">
              <ResumePreview />
            </div>
          </div>
        </main>

        <footer className="py-4 px-6 border-t text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Steller Resume Builder. All rights reserved.
          </p>
        </footer>
      </div>
    </ResumeProvider>
  );
};

export default Index;
