
export interface PersonalInfo {
  firstName: string;
  lastName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  profileImage?: string;
  summary: string;
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  level: number; // 1-5
}

export interface Project {
  id: string;
  name: string;
  description: string;
  url?: string;
  technologies: string[];
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  education: Education[];
  experience: Experience[];
  skills: Skill[];
  projects: Project[];
}

export interface ResumeTemplate {
  id: string;
  name: string;
  thumbnail: string;
  component: React.FC<{ data: ResumeData; primaryColor: string }>;
}

export enum SectionNames {
  PersonalInfo = "Personal Info",
  Education = "Education",
  Experience = "Experience",
  Skills = "Skills",
  Projects = "Projects",
}

export type ColorOptions = 
  | "indigo" 
  | "blue" 
  | "green" 
  | "red" 
  | "purple" 
  | "orange";
