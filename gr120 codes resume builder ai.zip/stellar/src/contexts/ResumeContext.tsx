
import React, { createContext, useContext, useState } from "react";
import { ResumeData, ColorOptions } from "../types/resume";
import { sampleResumeData } from "../data/mockData";

interface ResumeContextType {
  resumeData: ResumeData;
  updateResumeData: (data: Partial<ResumeData>) => void;
  selectedTemplateId: string;
  setSelectedTemplateId: (id: string) => void;
  selectedColor: ColorOptions;
  setSelectedColor: (color: ColorOptions) => void;
}

const ResumeContext = createContext<ResumeContextType | undefined>(undefined);

export const ResumeProvider: React.FC<{ children: React.ReactNode }> = ({ 
  children 
}) => {
  const [resumeData, setResumeData] = useState<ResumeData>(sampleResumeData);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("classic");
  const [selectedColor, setSelectedColor] = useState<ColorOptions>("indigo");

  const updateResumeData = (data: Partial<ResumeData>) => {
    setResumeData((prev) => ({
      ...prev,
      ...data,
    }));
  };

  return (
    <ResumeContext.Provider
      value={{
        resumeData,
        updateResumeData,
        selectedTemplateId,
        setSelectedTemplateId,
        selectedColor,
        setSelectedColor,
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
};

export const useResume = () => {
  const context = useContext(ResumeContext);
  if (context === undefined) {
    throw new Error("useResume must be used within a ResumeProvider");
  }
  return context;
};
