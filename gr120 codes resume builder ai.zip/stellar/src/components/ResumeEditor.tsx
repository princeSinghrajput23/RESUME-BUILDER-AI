
import React, { useState } from "react";
import { useResume } from "../contexts/ResumeContext";
import { SectionNames } from "../types/resume";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

import PersonalInfoForm from "./forms/PersonalInfoForm";
import EducationForm from "./forms/EducationForm";
import ExperienceForm from "./forms/ExperienceForm";
import SkillsForm from "./forms/SkillsForm";
import ProjectsForm from "./forms/ProjectsForm";

const ResumeEditor: React.FC = () => {
  const { resumeData, updateResumeData } = useResume();
  const [activeTab, setActiveTab] = useState<string>(SectionNames.PersonalInfo);

  const handlePersonalInfoUpdate = (personalInfo: typeof resumeData.personalInfo) => {
    updateResumeData({ personalInfo });
  };

  const handleEducationUpdate = (education: typeof resumeData.education) => {
    updateResumeData({ education });
  };

  const handleExperienceUpdate = (experience: typeof resumeData.experience) => {
    updateResumeData({ experience });
  };

  const handleSkillsUpdate = (skills: typeof resumeData.skills) => {
    updateResumeData({ skills });
  };

  const handleProjectsUpdate = (projects: typeof resumeData.projects) => {
    updateResumeData({ projects });
  };

  return (
    <Card className="h-full border">
      <Tabs 
        defaultValue={SectionNames.PersonalInfo} 
        className="h-full flex flex-col"
        value={activeTab}
        onValueChange={setActiveTab}
      >
        <div className="p-1 bg-muted/50 border-b">
          <TabsList className="w-full h-auto flex flex-wrap gap-1 bg-transparent">
            <TabsTrigger value={SectionNames.PersonalInfo} className="flex-grow data-[state=active]:bg-background">
              Personal Info
            </TabsTrigger>
            <TabsTrigger value={SectionNames.Education} className="flex-grow data-[state=active]:bg-background">
              Education
            </TabsTrigger>
            <TabsTrigger value={SectionNames.Experience} className="flex-grow data-[state=active]:bg-background">
              Experience
            </TabsTrigger>
            <TabsTrigger value={SectionNames.Skills} className="flex-grow data-[state=active]:bg-background">
              Skills
            </TabsTrigger>
            <TabsTrigger value={SectionNames.Projects} className="flex-grow data-[state=active]:bg-background">
              Projects
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-grow relative">
          <ScrollArea className="absolute inset-0">
            <div className="p-4">
              <TabsContent value={SectionNames.PersonalInfo} className="m-0 p-0">
                <PersonalInfoForm 
                  data={resumeData.personalInfo} 
                  onUpdate={handlePersonalInfoUpdate}
                />
              </TabsContent>
              
              <TabsContent value={SectionNames.Education} className="m-0 p-0">
                <EducationForm 
                  education={resumeData.education} 
                  onUpdate={handleEducationUpdate}
                />
              </TabsContent>
              
              <TabsContent value={SectionNames.Experience} className="m-0 p-0">
                <ExperienceForm 
                  experience={resumeData.experience} 
                  onUpdate={handleExperienceUpdate}
                />
              </TabsContent>
              
              <TabsContent value={SectionNames.Skills} className="m-0 p-0">
                <SkillsForm 
                  skills={resumeData.skills} 
                  onUpdate={handleSkillsUpdate}
                />
              </TabsContent>
              
              <TabsContent value={SectionNames.Projects} className="m-0 p-0">
                <ProjectsForm 
                  projects={resumeData.projects} 
                  onUpdate={handleProjectsUpdate}
                />
              </TabsContent>
            </div>
          </ScrollArea>
        </div>

        <div className="p-4 border-t flex justify-between">
          <Button
            variant="outline"
            onClick={() => {
              const sectionNames = Object.values(SectionNames);
              const currentIndex = sectionNames.indexOf(activeTab as SectionNames);
              if (currentIndex > 0) {
                setActiveTab(sectionNames[currentIndex - 1]);
              }
            }}
            disabled={activeTab === SectionNames.PersonalInfo}
          >
            Previous
          </Button>
          
          <Button
            onClick={() => {
              const sectionNames = Object.values(SectionNames);
              const currentIndex = sectionNames.indexOf(activeTab as SectionNames);
              if (currentIndex < sectionNames.length - 1) {
                setActiveTab(sectionNames[currentIndex + 1]);
              }
            }}
            disabled={activeTab === SectionNames.Projects}
          >
            Next
          </Button>
        </div>
      </Tabs>
    </Card>
  );
};

export default ResumeEditor;
