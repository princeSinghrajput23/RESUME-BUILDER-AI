
import React, { useState } from "react";
import { PersonalInfo } from "../../types/resume";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PersonalInfoFormProps {
  data: PersonalInfo;
  onUpdate: (data: PersonalInfo) => void;
}

const PersonalInfoForm: React.FC<PersonalInfoFormProps> = ({ data, onUpdate }) => {
  const [formData, setFormData] = useState<PersonalInfo>(data);
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    onUpdate({ ...formData, [name]: value });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024 * 2) { // 2MB limit
        toast({
          title: "Image too large",
          description: "Please choose an image under 2MB",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setFormData((prev) => ({ ...prev, profileImage: result }));
        onUpdate({ ...formData, profileImage: result });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">First Name</Label>
          <Input
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
        </div>
        <div>
          <Label htmlFor="lastName">Last Name</Label>
          <Input
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="title">Professional Title</Label>
        <Input
          id="title"
          name="title"
          placeholder="e.g. Senior Software Engineer"
          value={formData.title}
          onChange={handleChange}
        />
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
        />
      </div>

      <div>
        <Label htmlFor="phone">Phone</Label>
        <Input
          id="phone"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
        />
      </div>

      <div>
        <Label htmlFor="location">Location</Label>
        <Input
          id="location"
          name="location"
          placeholder="e.g. San Francisco, CA"
          value={formData.location}
          onChange={handleChange}
        />
      </div>

      <div>
        <Label htmlFor="website">Website (optional)</Label>
        <Input
          id="website"
          name="website"
          placeholder="e.g. yourwebsite.com"
          value={formData.website || ""}
          onChange={handleChange}
        />
      </div>

      <div>
        <Label htmlFor="profileImage">Profile Photo</Label>
        <div className="mt-1 flex items-center">
          {formData.profileImage ? (
            <div className="flex items-center gap-2">
              <img
                src={formData.profileImage}
                alt="Profile"
                className="w-12 h-12 rounded-full object-cover"
              />
              <Button
                variant="outline"
                size="sm"
                type="button"
                onClick={() => {
                  setFormData((prev) => ({ ...prev, profileImage: undefined }));
                  onUpdate({ ...formData, profileImage: undefined });
                }}
              >
                Remove
              </Button>
            </div>
          ) : (
            <div>
              <label
                htmlFor="photo-upload"
                className="cursor-pointer flex items-center gap-2"
              >
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                >
                  <Upload className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  Upload a photo
                </span>
              </label>
              <input
                id="photo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </div>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="summary">Professional Summary</Label>
        <Textarea
          id="summary"
          name="summary"
          placeholder="Write a short professional summary"
          className="h-24"
          value={formData.summary}
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default PersonalInfoForm;
