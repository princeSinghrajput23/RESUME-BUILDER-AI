
import React, { useState } from "react";
import { Experience } from "../../types/resume";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash, Plus } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

interface ExperienceFormProps {
  experience: Experience[];
  onUpdate: (experience: Experience[]) => void;
}

const ExperienceForm: React.FC<ExperienceFormProps> = ({ experience, onUpdate }) => {
  const [experienceItems, setExperienceItems] = useState<Experience[]>(experience);

  const handleAdd = () => {
    const newExperience: Experience = {
      id: uuidv4(),
      company: "",
      position: "",
      location: "",
      startDate: "",
      endDate: "",
      current: false,
      description: "",
    };
    
    const updatedExperience = [...experienceItems, newExperience];
    setExperienceItems(updatedExperience);
    onUpdate(updatedExperience);
  };

  const handleDelete = (id: string) => {
    const updatedExperience = experienceItems.filter((exp) => exp.id !== id);
    setExperienceItems(updatedExperience);
    onUpdate(updatedExperience);
  };

  const handleChange = (id: string, field: keyof Experience, value: any) => {
    const updatedExperience = experienceItems.map((exp) => {
      if (exp.id === id) {
        const updatedExp = { ...exp, [field]: value };
        
        // If the "current" checkbox is checked, clear the end date
        if (field === "current" && value === true) {
          updatedExp.endDate = "Present";
        } else if (field === "current" && value === false) {
          updatedExp.endDate = "";
        }
        
        return updatedExp;
      }
      return exp;
    });
    
    setExperienceItems(updatedExperience);
    onUpdate(updatedExperience);
  };

  return (
    <div className="space-y-4">
      {experienceItems.map((exp) => (
        <Card key={exp.id} className="relative">
          <CardContent className="pt-6">
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 h-6 w-6"
              onClick={() => handleDelete(exp.id)}
            >
              <Trash className="h-4 w-4" />
            </Button>

            <div className="grid grid-cols-1 gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor={`company-${exp.id}`}>Company</Label>
                  <Input
                    id={`company-${exp.id}`}
                    value={exp.company}
                    onChange={(e) => handleChange(exp.id, "company", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor={`position-${exp.id}`}>Position</Label>
                  <Input
                    id={`position-${exp.id}`}
                    value={exp.position}
                    onChange={(e) => handleChange(exp.id, "position", e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor={`location-${exp.id}`}>Location</Label>
                <Input
                  id={`location-${exp.id}`}
                  value={exp.location}
                  onChange={(e) => handleChange(exp.id, "location", e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor={`start-${exp.id}`}>Start Date</Label>
                  <Input
                    id={`start-${exp.id}`}
                    value={exp.startDate}
                    onChange={(e) => handleChange(exp.id, "startDate", e.target.value)}
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Checkbox
                      id={`current-${exp.id}`}
                      checked={exp.current}
                      onCheckedChange={(checked) => 
                        handleChange(exp.id, "current", checked === true)
                      }
                    />
                    <label
                      htmlFor={`current-${exp.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I currently work here
                    </label>
                  </div>
                  <Label htmlFor={`end-${exp.id}`}>End Date</Label>
                  <Input
                    id={`end-${exp.id}`}
                    value={exp.current ? "Present" : exp.endDate}
                    onChange={(e) => handleChange(exp.id, "endDate", e.target.value)}
                    disabled={exp.current}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor={`description-${exp.id}`}>Description</Label>
                <Textarea
                  id={`description-${exp.id}`}
                  className="h-20"
                  value={exp.description}
                  onChange={(e) => handleChange(exp.id, "description", e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={handleAdd}
      >
        <Plus className="mr-2 h-4 w-4" /> Add Experience
      </Button>
    </div>
  );
};

export default ExperienceForm;
