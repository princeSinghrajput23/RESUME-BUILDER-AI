
import React, { useState } from "react";
import { Skill } from "../../types/resume";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Trash, Plus } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

interface SkillsFormProps {
  skills: Skill[];
  onUpdate: (skills: Skill[]) => void;
}

const SkillsForm: React.FC<SkillsFormProps> = ({ skills, onUpdate }) => {
  const [skillItems, setSkillItems] = useState<Skill[]>(skills);

  const handleAdd = () => {
    const newSkill: Skill = {
      id: uuidv4(),
      name: "",
      level: 3,
    };
    
    const updatedSkills = [...skillItems, newSkill];
    setSkillItems(updatedSkills);
    onUpdate(updatedSkills);
  };

  const handleDelete = (id: string) => {
    const updatedSkills = skillItems.filter((skill) => skill.id !== id);
    setSkillItems(updatedSkills);
    onUpdate(updatedSkills);
  };

  const handleNameChange = (id: string, value: string) => {
    const updatedSkills = skillItems.map((skill) =>
      skill.id === id ? { ...skill, name: value } : skill
    );
    setSkillItems(updatedSkills);
    onUpdate(updatedSkills);
  };

  const handleLevelChange = (id: string, value: number[]) => {
    const updatedSkills = skillItems.map((skill) =>
      skill.id === id ? { ...skill, level: value[0] } : skill
    );
    setSkillItems(updatedSkills);
    onUpdate(updatedSkills);
  };

  return (
    <div className="space-y-4">
      {skillItems.map((skill) => (
        <Card key={skill.id} className="relative">
          <CardContent className="pt-6">
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 h-6 w-6"
              onClick={() => handleDelete(skill.id)}
            >
              <Trash className="h-4 w-4" />
            </Button>

            <div className="space-y-4">
              <div>
                <Label htmlFor={`skill-name-${skill.id}`}>Skill Name</Label>
                <Input
                  id={`skill-name-${skill.id}`}
                  value={skill.name}
                  onChange={(e) => handleNameChange(skill.id, e.target.value)}
                  placeholder="e.g. JavaScript, Project Management, Adobe Photoshop"
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <Label htmlFor={`skill-level-${skill.id}`}>Proficiency Level</Label>
                  <span className="text-sm text-muted-foreground">
                    {skill.level}/5
                  </span>
                </div>
                <Slider
                  id={`skill-level-${skill.id}`}
                  min={1}
                  max={5}
                  step={1}
                  defaultValue={[skill.level]}
                  onValueChange={(value) => handleLevelChange(skill.id, value)}
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-muted-foreground">Beginner</span>
                  <span className="text-xs text-muted-foreground">Expert</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={handleAdd}
      >
        <Plus className="mr-2 h-4 w-4" /> Add Skill
      </Button>
    </div>
  );
};

export default SkillsForm;
