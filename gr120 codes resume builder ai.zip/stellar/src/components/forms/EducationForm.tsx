
import React, { useState } from "react";
import { Education } from "../../types/resume";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Trash, Plus } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

interface EducationFormProps {
  education: Education[];
  onUpdate: (education: Education[]) => void;
}

const EducationForm: React.FC<EducationFormProps> = ({ education, onUpdate }) => {
  const [educationItems, setEducationItems] = useState<Education[]>(education);

  const handleAdd = () => {
    const newEducation: Education = {
      id: uuidv4(),
      institution: "",
      degree: "",
      fieldOfStudy: "",
      startDate: "",
      endDate: "",
      description: "",
    };
    
    const updatedEducation = [...educationItems, newEducation];
    setEducationItems(updatedEducation);
    onUpdate(updatedEducation);
  };

  const handleDelete = (id: string) => {
    const updatedEducation = educationItems.filter((edu) => edu.id !== id);
    setEducationItems(updatedEducation);
    onUpdate(updatedEducation);
  };

  const handleChange = (id: string, field: keyof Education, value: string) => {
    const updatedEducation = educationItems.map((edu) =>
      edu.id === id ? { ...edu, [field]: value } : edu
    );
    setEducationItems(updatedEducation);
    onUpdate(updatedEducation);
  };

  return (
    <div className="space-y-4">
      {educationItems.map((edu) => (
        <Card key={edu.id} className="relative">
          <CardContent className="pt-6">
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 h-6 w-6"
              onClick={() => handleDelete(edu.id)}
            >
              <Trash className="h-4 w-4" />
            </Button>

            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor={`institution-${edu.id}`}>Institution</Label>
                <Input
                  id={`institution-${edu.id}`}
                  value={edu.institution}
                  onChange={(e) => handleChange(edu.id, "institution", e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor={`degree-${edu.id}`}>Degree</Label>
                  <Input
                    id={`degree-${edu.id}`}
                    value={edu.degree}
                    onChange={(e) => handleChange(edu.id, "degree", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor={`field-${edu.id}`}>Field of Study</Label>
                  <Input
                    id={`field-${edu.id}`}
                    value={edu.fieldOfStudy}
                    onChange={(e) => handleChange(edu.id, "fieldOfStudy", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor={`start-${edu.id}`}>Start Date</Label>
                  <Input
                    id={`start-${edu.id}`}
                    value={edu.startDate}
                    onChange={(e) => handleChange(edu.id, "startDate", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor={`end-${edu.id}`}>End Date</Label>
                  <Input
                    id={`end-${edu.id}`}
                    value={edu.endDate}
                    onChange={(e) => handleChange(edu.id, "endDate", e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor={`description-${edu.id}`}>Description</Label>
                <Textarea
                  id={`description-${edu.id}`}
                  className="h-20"
                  value={edu.description}
                  onChange={(e) => handleChange(edu.id, "description", e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={handleAdd}
      >
        <Plus className="mr-2 h-4 w-4" /> Add Education
      </Button>
    </div>
  );
};

export default EducationForm;
