
import React, { useState } from "react";
import { Project } from "../../types/resume";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Trash, Plus, X } from "lucide-react";
import { v4 as uuidv4 } from "uuid";

interface ProjectsFormProps {
  projects: Project[];
  onUpdate: (projects: Project[]) => void;
}

const ProjectsForm: React.FC<ProjectsFormProps> = ({ projects, onUpdate }) => {
  const [projectItems, setProjectItems] = useState<Project[]>(projects);
  const [newTech, setNewTech] = useState<string>("");

  const handleAdd = () => {
    const newProject: Project = {
      id: uuidv4(),
      name: "",
      description: "",
      technologies: [],
    };
    
    const updatedProjects = [...projectItems, newProject];
    setProjectItems(updatedProjects);
    onUpdate(updatedProjects);
  };

  const handleDelete = (id: string) => {
    const updatedProjects = projectItems.filter((project) => project.id !== id);
    setProjectItems(updatedProjects);
    onUpdate(updatedProjects);
  };

  const handleChange = (id: string, field: keyof Project, value: any) => {
    const updatedProjects = projectItems.map((project) =>
      project.id === id ? { ...project, [field]: value } : project
    );
    setProjectItems(updatedProjects);
    onUpdate(updatedProjects);
  };

  const handleAddTechnology = (id: string, tech: string) => {
    if (!tech.trim()) return;
    
    const updatedProjects = projectItems.map((project) => {
      if (project.id === id) {
        return {
          ...project,
          technologies: [...project.technologies, tech.trim()],
        };
      }
      return project;
    });
    
    setProjectItems(updatedProjects);
    onUpdate(updatedProjects);
    setNewTech("");
  };

  const handleDeleteTechnology = (projectId: string, techIndex: number) => {
    const updatedProjects = projectItems.map((project) => {
      if (project.id === projectId) {
        const updatedTechnologies = [...project.technologies];
        updatedTechnologies.splice(techIndex, 1);
        return {
          ...project,
          technologies: updatedTechnologies,
        };
      }
      return project;
    });
    
    setProjectItems(updatedProjects);
    onUpdate(updatedProjects);
  };

  return (
    <div className="space-y-4">
      {projectItems.map((project) => (
        <Card key={project.id} className="relative">
          <CardContent className="pt-6">
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 h-6 w-6"
              onClick={() => handleDelete(project.id)}
            >
              <Trash className="h-4 w-4" />
            </Button>

            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor={`project-name-${project.id}`}>Project Name</Label>
                <Input
                  id={`project-name-${project.id}`}
                  value={project.name}
                  onChange={(e) => handleChange(project.id, "name", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor={`project-description-${project.id}`}>Description</Label>
                <Textarea
                  id={`project-description-${project.id}`}
                  className="h-20"
                  value={project.description}
                  onChange={(e) => handleChange(project.id, "description", e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor={`project-url-${project.id}`}>URL (optional)</Label>
                <Input
                  id={`project-url-${project.id}`}
                  value={project.url || ""}
                  placeholder="e.g. https://github.com/username/project"
                  onChange={(e) => handleChange(project.id, "url", e.target.value)}
                />
              </div>

              <div>
                <Label>Technologies Used</Label>
                <div className="flex flex-wrap gap-1 my-2">
                  {project.technologies.map((tech, index) => (
                    <div
                      key={index}
                      className="bg-muted px-2 py-1 rounded-md flex items-center gap-1 text-sm"
                    >
                      {tech}
                      <button
                        type="button"
                        onClick={() => handleDeleteTechnology(project.id, index)}
                        className="text-muted-foreground hover:text-foreground"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="e.g. React, Node.js"
                    value={newTech}
                    onChange={(e) => setNewTech(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAddTechnology(project.id, newTech);
                      }
                    }}
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => handleAddTechnology(project.id, newTech)}
                  >
                    Add
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={handleAdd}
      >
        <Plus className="mr-2 h-4 w-4" /> Add Project
      </Button>
    </div>
  );
};

export default ProjectsForm;
