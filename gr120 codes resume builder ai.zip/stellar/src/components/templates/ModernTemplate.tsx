
import React from "react";
import { ResumeData } from "../../types/resume";
import { Phone, Mail, Globe, MapPin } from "lucide-react";

interface ModernTemplateProps {
  data: ResumeData;
  primaryColor: string;
}

const ModernTemplate: React.FC<ModernTemplateProps> = ({ data, primaryColor }) => {
  const { personalInfo, education, experience, skills, projects } = data;
  
  const colorClasses = {
    indigo: "bg-indigo-600",
    blue: "bg-blue-600",
    green: "bg-green-600",
    red: "bg-red-600",
    purple: "bg-purple-600", 
    orange: "bg-orange-600",
  };
  
  const textColorClasses = {
    indigo: "text-indigo-600",
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600",
    purple: "text-purple-600",
    orange: "text-orange-600",
  };
  
  const colorClass = colorClasses[primaryColor as keyof typeof colorClasses] || colorClasses.indigo;
  const textColorClass = textColorClasses[primaryColor as keyof typeof textColorClasses] || textColorClasses.indigo;

  return (
    <div className="resume-page bg-white text-gray-800 font-sans">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">
            {personalInfo.firstName} <span className={textColorClass}>{personalInfo.lastName}</span>
          </h1>
          <p className="text-xl text-gray-600 mt-1">{personalInfo.title}</p>
        </div>
        
        {personalInfo.profileImage && (
          <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-gray-200">
            <img 
              src={personalInfo.profileImage} 
              alt={`${personalInfo.firstName} ${personalInfo.lastName}`} 
              className="w-full h-full object-cover"
            />
          </div>
        )}
      </header>

      <div className={`p-3 ${colorClass} text-white rounded-md mb-6 flex flex-wrap gap-4 text-sm justify-between`}>
        <div className="flex items-center gap-1">
          <Phone size={16} className="text-white" />
          <span>{personalInfo.phone}</span>
        </div>
        <div className="flex items-center gap-1">
          <Mail size={16} className="text-white" />
          <span>{personalInfo.email}</span>
        </div>
        {personalInfo.website && (
          <div className="flex items-center gap-1">
            <Globe size={16} className="text-white" />
            <span>{personalInfo.website}</span>
          </div>
        )}
        <div className="flex items-center gap-1">
          <MapPin size={16} className="text-white" />
          <span>{personalInfo.location}</span>
        </div>
      </div>
      
      <p className="mb-6 text-sm border-l-4 pl-3 border-gray-300">{personalInfo.summary}</p>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2">
          <section className="mb-6">
            <h2 className={`text-lg font-bold mb-3 pb-1 border-b-2 ${textColorClass}`}>
              Experience
            </h2>
            {experience.map((exp) => (
              <div key={exp.id} className="mb-4">
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold text-base">{exp.position}</h3>
                  <span className="text-xs px-2 py-1 rounded bg-gray-200 text-gray-700">
                    {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                  </span>
                </div>
                <p className={`text-sm ${textColorClass} font-semibold`}>{exp.company}, {exp.location}</p>
                <p className="text-sm mt-1">{exp.description}</p>
              </div>
            ))}
          </section>

          <section className="mb-6">
            <h2 className={`text-lg font-bold mb-3 pb-1 border-b-2 ${textColorClass}`}>
              Projects
            </h2>
            {projects.map((project) => (
              <div key={project.id} className="mb-4">
                <h3 className="font-bold">{project.name}</h3>
                <p className="text-sm mb-1">{project.description}</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {project.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="text-xs px-2 py-0.5 rounded bg-gray-200 text-gray-700"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </section>
        </div>

        <div className="col-span-1">
          <section className="mb-6">
            <h2 className={`text-lg font-bold mb-3 pb-1 border-b-2 ${textColorClass}`}>
              Education
            </h2>
            {education.map((edu) => (
              <div key={edu.id} className="mb-4">
                <h3 className="font-bold">{edu.institution}</h3>
                <p className="text-sm font-medium">{edu.degree} in {edu.fieldOfStudy}</p>
                <p className="text-xs text-gray-600">{edu.startDate} - {edu.endDate}</p>
                <p className="text-xs mt-1">{edu.description}</p>
              </div>
            ))}
          </section>

          <section>
            <h2 className={`text-lg font-bold mb-3 pb-1 border-b-2 ${textColorClass}`}>
              Skills
            </h2>
            {skills.map((skill) => (
              <div key={skill.id} className="mb-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">{skill.name}</span>
                  <span className="text-xs text-gray-500">{skill.level}/5</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                  <div
                    className={`h-1.5 rounded-full ${colorClass}`}
                    style={{ width: `${(skill.level / 5) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </section>
        </div>
      </div>
    </div>
  );
};

export default ModernTemplate;
