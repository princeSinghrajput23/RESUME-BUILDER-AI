
import React from "react";
import { ResumeData } from "../../types/resume";
import { Phone, Mail, Globe, MapPin } from "lucide-react";

interface ClassicTemplateProps {
  data: ResumeData;
  primaryColor: string;
}

const ClassicTemplate: React.FC<ClassicTemplateProps> = ({ data, primaryColor }) => {
  const { personalInfo, education, experience, skills, projects } = data;
  
  const colorClasses = {
    indigo: "text-indigo-600",
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600",
    purple: "text-purple-600",
    orange: "text-orange-600",
  };
  
  const colorClass = colorClasses[primaryColor as keyof typeof colorClasses] || colorClasses.indigo;

  return (
    <div className="resume-page bg-white text-gray-800 font-sans">
      <header className="mb-6">
        <h1 className={`text-3xl font-bold ${colorClass}`}>
          {personalInfo.firstName} {personalInfo.lastName}
        </h1>
        <p className="text-xl text-gray-600 mt-1">{personalInfo.title}</p>
        
        <div className="flex flex-wrap gap-4 mt-3 text-sm">
          <div className="flex items-center gap-1">
            <Phone size={16} className={colorClass} />
            <span>{personalInfo.phone}</span>
          </div>
          <div className="flex items-center gap-1">
            <Mail size={16} className={colorClass} />
            <span>{personalInfo.email}</span>
          </div>
          {personalInfo.website && (
            <div className="flex items-center gap-1">
              <Globe size={16} className={colorClass} />
              <span>{personalInfo.website}</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <MapPin size={16} className={colorClass} />
            <span>{personalInfo.location}</span>
          </div>
        </div>
        
        <p className="mt-4 text-sm">{personalInfo.summary}</p>
      </header>

      <section className="mb-6">
        <h2 className={`text-lg font-bold mb-2 pb-1 border-b ${colorClass} border-gray-300`}>
          Experience
        </h2>
        {experience.map((exp) => (
          <div key={exp.id} className="mb-4">
            <div className="flex justify-between">
              <h3 className="font-bold">{exp.position}</h3>
              <span className="text-sm text-gray-600">
                {exp.startDate} - {exp.current ? "Present" : exp.endDate}
              </span>
            </div>
            <p className="text-gray-700">{exp.company}, {exp.location}</p>
            <p className="text-sm mt-1">{exp.description}</p>
          </div>
        ))}
      </section>

      <section className="mb-6">
        <h2 className={`text-lg font-bold mb-2 pb-1 border-b ${colorClass} border-gray-300`}>
          Education
        </h2>
        {education.map((edu) => (
          <div key={edu.id} className="mb-4">
            <div className="flex justify-between">
              <h3 className="font-bold">{edu.degree} in {edu.fieldOfStudy}</h3>
              <span className="text-sm text-gray-600">
                {edu.startDate} - {edu.endDate}
              </span>
            </div>
            <p className="text-gray-700">{edu.institution}</p>
            <p className="text-sm mt-1">{edu.description}</p>
          </div>
        ))}
      </section>

      <section className="mb-6">
        <h2 className={`text-lg font-bold mb-2 pb-1 border-b ${colorClass} border-gray-300`}>
          Skills
        </h2>
        <div className="flex flex-wrap gap-y-3">
          {skills.map((skill) => (
            <div key={skill.id} className="w-1/3">
              <div className="flex items-center">
                <span className="mr-2">{skill.name}</span>
                <div className="flex space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 w-2 rounded-full ${
                        i < skill.level ? colorClass.replace("text-", "bg-") : "bg-gray-200"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-6">
        <h2 className={`text-lg font-bold mb-2 pb-1 border-b ${colorClass} border-gray-300`}>
          Projects
        </h2>
        {projects.map((project) => (
          <div key={project.id} className="mb-4">
            <h3 className="font-bold">{project.name}</h3>
            <p className="text-sm mb-1">{project.description}</p>
            <div className="flex flex-wrap gap-2 mt-1">
              {project.technologies.map((tech, index) => (
                <span
                  key={index}
                  className={`text-xs px-2 py-1 rounded ${
                    colorClass.replace("text-", "bg-")
                  } bg-opacity-20`}
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};

export default ClassicTemplate;
