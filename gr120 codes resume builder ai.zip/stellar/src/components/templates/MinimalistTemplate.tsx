
import React from "react";
import { ResumeData } from "../../types/resume";

interface MinimalistTemplateProps {
  data: ResumeData;
  primaryColor: string;
}

const MinimalistTemplate: React.FC<MinimalistTemplateProps> = ({ data, primaryColor }) => {
  const { personalInfo, education, experience, skills, projects } = data;
  
  const colorClasses = {
    indigo: "border-indigo-600",
    blue: "border-blue-600",
    green: "border-green-600",
    red: "border-red-600",
    purple: "border-purple-600",
    orange: "border-orange-600",
  };
  
  const textColorClasses = {
    indigo: "text-indigo-600",
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600",
    purple: "text-purple-600",
    orange: "text-orange-600",
  };
  
  const borderClass = colorClasses[primaryColor as keyof typeof colorClasses] || colorClasses.indigo;
  const textColorClass = textColorClasses[primaryColor as keyof typeof textColorClasses] || textColorClasses.indigo;

  return (
    <div className="resume-page bg-white text-gray-800 font-sans">
      <header className="mb-8 pb-4 border-b border-gray-200">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-light tracking-tight">
              {personalInfo.firstName} <span className="font-medium">{personalInfo.lastName}</span>
            </h1>
            <p className="text-lg text-gray-500 mt-1">{personalInfo.title}</p>
          </div>
          <div className="text-right text-sm">
            <p>{personalInfo.email}</p>
            <p>{personalInfo.phone}</p>
            <p>{personalInfo.location}</p>
            {personalInfo.website && <p>{personalInfo.website}</p>}
          </div>
        </div>
      </header>

      <div className={`border-l-4 ${borderClass} pl-4 mb-6`}>
        <p className="text-sm italic">{personalInfo.summary}</p>
      </div>

      <section className="mb-6">
        <h2 className={`text-base uppercase tracking-widest mb-3 ${textColorClass}`}>
          Experience
        </h2>
        {experience.map((exp) => (
          <div key={exp.id} className="mb-5">
            <div className="flex justify-between">
              <h3 className="font-medium">{exp.position}</h3>
              <span className="text-sm text-gray-500">
                {exp.startDate} – {exp.current ? "Present" : exp.endDate}
              </span>
            </div>
            <p className="text-sm text-gray-600 mb-2">{exp.company}, {exp.location}</p>
            <p className="text-sm">{exp.description}</p>
          </div>
        ))}
      </section>

      <section className="mb-6">
        <h2 className={`text-base uppercase tracking-widest mb-3 ${textColorClass}`}>
          Education
        </h2>
        {education.map((edu) => (
          <div key={edu.id} className="mb-4">
            <div className="flex justify-between">
              <h3 className="font-medium">{edu.institution}</h3>
              <span className="text-sm text-gray-500">
                {edu.startDate} – {edu.endDate}
              </span>
            </div>
            <p className="text-sm text-gray-600">{edu.degree}, {edu.fieldOfStudy}</p>
            <p className="text-sm">{edu.description}</p>
          </div>
        ))}
      </section>

      <div className="grid grid-cols-2 gap-6">
        <section>
          <h2 className={`text-base uppercase tracking-widest mb-3 ${textColorClass}`}>
            Skills
          </h2>
          <div className="flex flex-wrap">
            {skills.map((skill) => (
              <div key={skill.id} className="mr-1 mb-1">
                <span className="inline-block px-3 py-1 text-xs border border-gray-300 rounded-full">
                  {skill.name}
                </span>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className={`text-base uppercase tracking-widest mb-3 ${textColorClass}`}>
            Projects
          </h2>
          {projects.map((project) => (
            <div key={project.id} className="mb-3">
              <h3 className="font-medium">{project.name}</h3>
              <p className="text-sm">{project.description}</p>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
};

export default MinimalistTemplate;
