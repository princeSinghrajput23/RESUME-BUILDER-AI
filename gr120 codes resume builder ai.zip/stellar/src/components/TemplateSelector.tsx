
import React from "react";
import { ResumeTemplate } from "../types/resume";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface TemplateSelectorProps {
  templates: ResumeTemplate[];
  selectedTemplateId: string;
  onSelectTemplate: (templateId: string) => void;
}

const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  templates,
  selectedTemplateId,
  onSelectTemplate,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {templates.map((template) => (
        <Card
          key={template.id}
          className={cn(
            "cursor-pointer transition-all overflow-hidden",
            selectedTemplateId === template.id
              ? "ring-2 ring-primary"
              : "hover:shadow-md"
          )}
          onClick={() => onSelectTemplate(template.id)}
        >
          <CardContent className="p-2">
            <div className="aspect-[8.5/11] relative overflow-hidden rounded-sm border">
              <img
                src={template.thumbnail}
                alt={template.name}
                className="object-cover w-full h-full"
              />
            </div>
            <p className="text-center mt-2 font-medium text-sm">
              {template.name}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TemplateSelector;
