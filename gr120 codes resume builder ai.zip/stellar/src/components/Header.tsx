
import React from "react";
import { Star } from "lucide-react";

const Header: React.FC = () => {
  return (
    <header className="py-4 px-6 flex items-center justify-between border-b">
      <div className="flex items-center">
        <Star className="h-6 w-6 text-primary mr-2" />
        <h1 className="text-2xl font-bold">Steller</h1>
      </div>
      <div>
        <p className="text-sm text-muted-foreground">Resume Builder</p>
      </div>
    </header>
  );
};

export default Header;
