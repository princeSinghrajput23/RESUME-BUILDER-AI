
import React from "react";
import { ColorOptions } from "../types/resume";
import { cn } from "@/lib/utils";

interface ColorPickerProps {
  selectedColor: ColorOptions;
  onColorChange: (color: ColorOptions) => void;
}

const ColorPicker: React.FC<ColorPickerProps> = ({
  selectedColor,
  onColorChange,
}) => {
  const colors: { label: string; value: ColorOptions; class: string }[] = [
    { label: "Indigo", value: "indigo", class: "bg-indigo-500" },
    { label: "Blue", value: "blue", class: "bg-blue-500" },
    { label: "Green", value: "green", class: "bg-green-500" },
    { label: "Red", value: "red", class: "bg-red-500" },
    { label: "Purple", value: "purple", class: "bg-purple-500" },
    { label: "Orange", value: "orange", class: "bg-orange-500" },
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {colors.map((color) => (
        <button
          key={color.value}
          className={cn(
            "w-8 h-8 rounded-full transition-all",
            color.class,
            selectedColor === color.value
              ? "ring-2 ring-offset-2 ring-gray-800"
              : "hover:opacity-80"
          )}
          onClick={() => onColorChange(color.value)}
          title={color.label}
          type="button"
          aria-label={`Select ${color.label} color`}
        />
      ))}
    </div>
  );
};

export default ColorPicker;
