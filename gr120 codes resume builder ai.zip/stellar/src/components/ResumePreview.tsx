
import React from "react";
import { useResume } from "../contexts/ResumeContext";
import { templates } from "../data/templates";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";

import TemplateSelector from "./TemplateSelector";
import ColorPicker from "./ColorPicker";
import { Button } from "./ui/button";
import { Download, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ResumePreview: React.FC = () => {
  const { resumeData, selectedTemplateId, setSelectedTemplateId, selectedColor, setSelectedColor } = useResume();
  const { toast } = useToast();

  const selectedTemplate = templates.find((t) => t.id === selectedTemplateId);
  const TemplateComponent = selectedTemplate?.component;

  const handleExportPDF = () => {
    toast({
      title: "Exporting PDF",
      description: "Your resume is being prepared for download...",
    });
    
    window.print();
  };

  return (
    <div className="flex flex-col h-full gap-4">
      <Card className="p-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <h3 className="font-medium">Template Style</h3>
            <TemplateSelector
              templates={templates}
              selectedTemplateId={selectedTemplateId}
              onSelectTemplate={setSelectedTemplateId}
            />
          </div>
          
          <div className="space-y-2">
            <h3 className="font-medium">Color Theme</h3>
            <ColorPicker 
              selectedColor={selectedColor}
              onColorChange={setSelectedColor}
            />
          </div>
        </div>
      </Card>

      <Card className="p-4 flex-grow flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium">Preview</h3>
          <Button onClick={handleExportPDF} className="gap-2">
            <Download className="h-4 w-4" />
            Export PDF
          </Button>
        </div>
        
        <div className="flex-grow relative">
          <ScrollArea className="absolute inset-0">
            <div className="flex flex-col items-center p-6 no-print">
              {TemplateComponent ? (
                <div className="scale-[0.7] origin-top transform-gpu">
                  <TemplateComponent data={resumeData} primaryColor={selectedColor} />
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p>Template not found</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </Card>
    </div>
  );
};

export default ResumePreview;
